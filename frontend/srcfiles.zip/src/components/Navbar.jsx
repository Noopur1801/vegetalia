import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

export default function Navbar() {
   const { user, logout } = useContext(AuthContext);
   const navigate = useNavigate();

   const handleLogout = () => {
      logout();
      navigate('/login');
   };

   if (!user) return null; // Don't show navbar on login/register pages

   return (
      <nav style={{ backgroundColor: '#111827', padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'white' }}>
         <div style={{ fontWeight: 'bold', fontSize: '20px' }}>Vegetillya</div>

         <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
            {/* Dynamic Links based on Role */}
            {user.role === 'vendor' && (
               <>
                  <Link to="/vendor-dashboard" style={{ color: '#d1d5db', textDecoration: 'none' }}>Profile</Link>
                  <Link to="/vendor/products" style={{ color: '#d1d5db', textDecoration: 'none' }}>My Products</Link>
                  <Link to="/vendor/sales" style={{ color: '#10b981', fontWeight: 'bold', textDecoration: 'none' }}>Sales Board</Link>
               </>
            )}
            {user.role === 'buyer' && (
               <>
                  <Link to="/buyer/marketplace" style={{ color: '#10b981', fontWeight: 'bold', textDecoration: 'none' }}>Marketplace</Link>
                  <Link to="/buyer/orders" style={{ color: '#d1d5db', textDecoration: 'none' }}>Track Orders</Link>
                  <Link to="/buyer-dashboard" style={{ color: '#d1d5db', textDecoration: 'none' }}>Profile</Link>
               </>
            )}
            {user.role === 'driver' && (
               <>
                  <Link to="/driver-dashboard" style={{ color: '#d1d5db', textDecoration: 'none' }}>Profile</Link>
                  <Link to="/driver/deliveries" style={{ color: '#10b981', fontWeight: 'bold', textDecoration: 'none' }}>Find Deliveries</Link>
                  <Link to="/driver/active" style={{ color: '#10b981', fontWeight: 'bold', textDecoration: 'none' }}>My Route</Link>
               </>
            )}
            {user.role === 'admin' && (
               <>
                  <Link to="/admin-dashboard" style={{ color: '#d1d5db', textDecoration: 'none' }}>Dashboard</Link>
                  <Link to="/admin/orders" style={{ color: '#10b981', fontWeight: 'bold', textDecoration: 'none' }}>All Orders</Link>
               </>
            )}

            <button onClick={handleLogout} style={{ padding: '6px 12px', backgroundColor: '#dc2626', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
               Logout
            </button>
         </div>
      </nav>
   );
}