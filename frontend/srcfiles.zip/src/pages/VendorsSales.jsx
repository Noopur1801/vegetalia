import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

export default function VendorSales() {
   const [sales, setSales] = useState([]);
   const { token, user } = useContext(AuthContext);

   useEffect(() => {
      const fetchSales = async () => {
         try {
            const res = await axios.get('http://localhost:5000/api/orders/vendor-sales', {
               headers: { Authorization: `Bearer ${token}` }
            });
            setSales(res.data);
         } catch (err) { console.error(err); }
      };
      if (token) fetchSales();
   }, [token]);

   return (
      <div style={{ maxWidth: '900px', margin: '40px auto', padding: '0 20px', fontFamily: 'Inter, sans-serif' }}>
         <h1 style={{ marginBottom: '24px' }}>My Sales & Packing Board</h1>

         <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {sales.length === 0 ? (
               <p style={{ color: '#6b7280' }}>No sales yet. Keep adding fresh products!</p>
            ) : (
               sales.map(order => {
                  // Filter items so the vendor ONLY sees their own vegetables (in case buyer bought from multiple vendors)
                  const myItems = order.items.filter(item => item.vendorId === user.id);

                  return (
                     <div key={order._id} style={{ border: '1px solid #e5e7eb', borderRadius: '8px', overflow: 'hidden', backgroundColor: 'white' }}>

                        {/* Header: Timeline & Status */}
                        <div style={{ backgroundColor: order.deliveryType === 'Today' ? '#fef3c7' : '#d1fae5', padding: '12px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e5e7eb' }}>
                           <span style={{ fontWeight: 'bold', color: order.deliveryType === 'Today' ? '#b45309' : '#047857' }}>
                              {order.deliveryType === 'Today' ? '⚡ PACK TODAY' : '🗓️ PACK IN 15 DAYS'}
                           </span>
                           <span style={{ fontSize: '13px', fontWeight: 'bold', backgroundColor: 'white', padding: '4px 10px', borderRadius: '12px', border: '1px solid #d1d5db' }}>
                              Status: {order.status}
                           </span>
                        </div>

                        <div style={{ padding: '20px', display: 'flex', gap: '24px', flexWrap: 'wrap' }}>

                           {/* Left Column: What to Pack */}
                           <div style={{ flex: 2, minWidth: '250px' }}>
                              <h3 style={{ marginTop: 0, marginBottom: '12px', fontSize: '16px' }}>Items to Pack:</h3>
                              <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                                 {myItems.map(item => (
                                    <li key={item.productId} style={{ padding: '8px 0', borderBottom: '1px dashed #e5e7eb', display: 'flex', justifyContent: 'space-between' }}>
                                       <span>{item.quantity}x {item.name}</span>
                                       <span style={{ fontWeight: 'bold' }}>₹{item.price * item.quantity}</span>
                                    </li>
                                 ))}
                              </ul>
                           </div>

                           {/* Right Column: Buyer & Driver Info */}
                           <div style={{ flex: 1, minWidth: '200px', backgroundColor: '#f9fafb', padding: '16px', borderRadius: '8px' }}>
                              <h4 style={{ margin: '0 0 8px 0', color: '#4b5563' }}>🛒 Buyer Details</h4>
                              <p style={{ margin: '0 0 4px 0', fontSize: '14px', fontWeight: 'bold' }}>{order.buyerId?.name || 'Unknown'}</p>
                              <p style={{ margin: '0 0 16px 0', fontSize: '13px', color: '#6b7280' }}>{order.buyerId?.address || 'Address hidden'}</p>

                              <h4 style={{ margin: '0 0 8px 0', color: '#4b5563' }}>🚚 Driver Details</h4>
                              {order.driverId ? (
                                 <>
                                    <p style={{ margin: '0 0 4px 0', fontSize: '14px', fontWeight: 'bold' }}>{order.driverId.name}</p>
                                    <p style={{ margin: 0, fontSize: '13px', color: '#6b7280' }}>📱 {order.driverId.phone || 'No phone'}</p>
                                 </>
                              ) : (
                                 <p style={{ margin: 0, fontSize: '13px', color: '#9ca3af', fontStyle: 'italic' }}>Waiting for driver assignment...</p>
                              )}
                           </div>

                        </div>
                     </div>
                  );
               })
            )}
         </div>
      </div>
   );
}