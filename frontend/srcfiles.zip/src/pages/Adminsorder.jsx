import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

export default function AdminOrders() {
   const [orders, setOrders] = useState([]);
   const { token } = useContext(AuthContext);

   useEffect(() => {
      const fetchAllOrders = async () => {
         try {
            const res = await axios.get('http://localhost:5000/api/orders/all', {
               headers: { Authorization: `Bearer ${token}` }
            });
            setOrders(res.data);
         } catch (err) { console.error(err); }
      };
      if (token) fetchAllOrders();
   }, [token]);

   return (
      <div style={{ maxWidth: '1000px', margin: '40px auto', padding: '0 20px', fontFamily: 'Inter, sans-serif' }}>
         <h1 style={{ marginBottom: '24px' }}>System Orders Overlook</h1>

         <div style={{ backgroundColor: 'white', borderRadius: '8px', border: '1px solid #e5e7eb', overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
               <thead>
                  <tr style={{ backgroundColor: '#f3f4f6' }}>
                     <th style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>Order ID</th>
                     <th style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>Amount</th>
                     <th style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>Items</th>
                     <th style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>Status</th>
                     <th style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>Date</th>
                  </tr>
               </thead>
               <tbody>
                  {orders.length === 0 ? (
                     <tr>
                        <td colSpan="5" style={{ padding: '24px', textAlign: 'center', color: '#6b7280' }}>No orders placed yet.</td>
                     </tr>
                  ) : (
                     orders.map(order => (
                        <tr key={order._id}>
                           <td style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb', fontSize: '13px', color: '#6b7280' }}>
                              {order._id.slice(-6)} {/* Showing just the last 6 characters for a cleaner look */}
                           </td>
                           <td style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb', fontWeight: 'bold' }}>
                              ₹{order.totalAmount}
                           </td>
                           <td style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb', fontSize: '13px' }}>
                              {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                           </td>
                           <td style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb' }}>
                              <span style={{
                                 padding: '4px 8px',
                                 borderRadius: '12px',
                                 fontSize: '12px',
                                 backgroundColor: order.status === 'Pending' ? '#fef08a' : order.status === 'Accepted' ? '#bfdbfe' : '#dcfce7',
                                 color: order.status === 'Pending' ? '#854d0e' : order.status === 'Accepted' ? '#1e40af' : '#166534'
                              }}>
                                 {order.status}
                              </span>
                           </td>
                           <td style={{ padding: '12px 16px', borderBottom: '1px solid #e5e7eb', fontSize: '13px' }}>
                              {new Date(order.createdAt).toLocaleDateString()}
                           </td>
                        </tr>
                     ))
                  )}
               </tbody>
            </table>
         </div>
      </div>
   );
}