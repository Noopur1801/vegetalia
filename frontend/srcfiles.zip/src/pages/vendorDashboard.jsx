import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function VendorDashboard() {
   const [profile, setProfile] = useState(null);
   const [loading, setLoading] = useState(true);
   const [isEditing, setIsEditing] = useState(false);

   // Form State
   const [formData, setFormData] = useState({
      businessName: '',
      gstNumber: '',
      phone: ''
   });

   const { token, logout } = useContext(AuthContext);
   const navigate = useNavigate();

   useEffect(() => {
      const fetchProfile = async () => {
         try {
            const response = await axios.get('http://localhost:5000/api/vendor/profile', {
               headers: { Authorization: `Bearer ${token}` }
            });
            setProfile(response.data);
            setFormData({
               businessName: response.data.businessName || '',
               gstNumber: response.data.gstNumber || '',
               phone: response.data.phone || ''
            });
         } catch (error) {
            console.error("Error fetching profile", error);
         } finally {
            setLoading(false);
         }
      };

      if (token) fetchProfile();
   }, [token]);

   const handleLogout = () => {
      if (logout) logout();
      else localStorage.removeItem('token');
      navigate('/login');
   };

   const handleUpdate = async (e) => {
      e.preventDefault();
      try {
         const response = await axios.put('http://localhost:5000/api/vendor/profile', formData, {
            headers: { Authorization: `Bearer ${token}` }
         });
         setProfile(response.data.profile);
         setIsEditing(false);
      } catch (error) {
         console.error("Error updating profile", error);
         alert("Failed to update profile.");
      }
   };

   if (loading) return <div style={{ padding: '40px', textAlign: 'center' }} className="text-muted">Loading dashboard...</div>;

   return (
      <div className="dashboard-wrapper" style={{ maxWidth: '800px' }}>

         <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h1 className="heading-main" style={{ marginBottom: 0 }}>Vendor Dashboard</h1>
            <button onClick={handleLogout} className="btn-secondary" style={{ color: '#dc2626', borderColor: '#fee2e2', backgroundColor: '#fef2f2' }}>
               Sign Out
            </button>
         </div>

         <div className="dashboard-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e5e7eb', paddingBottom: '12px', marginBottom: '24px' }}>
               <h2 className="heading-sub" style={{ marginBottom: 0 }}>Business Profile</h2>
               {!isEditing && (
                  <button onClick={() => setIsEditing(true)} className="btn-secondary">
                     Edit Profile
                  </button>
               )}
            </div>

            {isEditing ? (
               <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                     <label className="text-muted" style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>Business Name</label>
                     <input type="text" value={formData.businessName} onChange={(e) => setFormData({ ...formData, businessName: e.target.value })} className="input-field" required />
                  </div>
                  <div>
                     <label className="text-muted" style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>GST Number</label>
                     <input type="text" value={formData.gstNumber} onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })} className="input-field" required />
                  </div>
                  <div>
                     <label className="text-muted" style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>Phone Number</label>
                     <input type="text" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="input-field" required />
                  </div>
                  <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
                     <button type="submit" className="btn-primary" style={{ width: 'auto' }}>Save Changes</button>
                     <button type="button" onClick={() => setIsEditing(false)} className="btn-secondary" style={{ width: 'auto' }}>Cancel</button>
                  </div>
               </form>
            ) : (
               <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
                  <div>
                     <p className="text-muted" style={{ margin: '0 0 4px 0' }}>Business Name</p>
                     <p style={{ margin: 0, fontWeight: '600' }}>{profile?.businessName || 'Not configured yet'}</p>
                  </div>
                  <div>
                     <p className="text-muted" style={{ margin: '0 0 4px 0' }}>GST Number</p>
                     <p style={{ margin: 0, fontWeight: '600' }}>{profile?.gstNumber || 'Not configured yet'}</p>
                  </div>
                  <div>
                     <p className="text-muted" style={{ margin: '0 0 4px 0' }}>Phone</p>
                     <p style={{ margin: 0, fontWeight: '600' }}>{profile?.phone || 'Not configured yet'}</p>
                  </div>
                  <div>
                     <p className="text-muted" style={{ margin: '0 0 4px 0' }}>Verification Status</p>
                     <span className={`badge ${profile?.isVerified ? 'badge-scheduled' : 'badge-today'}`} style={{ marginTop: '4px' }}>
                        {profile?.isVerified ? 'Verified' : 'Pending Admin Approval'}
                     </span>
                  </div>
               </div>
            )}
         </div>
      </div>
   );
}