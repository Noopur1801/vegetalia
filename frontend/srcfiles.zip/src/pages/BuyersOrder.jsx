import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

export default function BuyerOrders() {
   const [orders, setOrders] = useState([]);
   const { token } = useContext(AuthContext);

   useEffect(() => {
      const fetchMyOrders = async () => {
         try {
            const res = await axios.get('http://localhost:5000/api/orders/my-orders', {
               headers: { Authorization: `Bearer ${token}` }
            });
            setOrders(res.data);
         } catch (err) { console.error(err); }
      };
      if (token) fetchMyOrders();
   }, [token]);

   // Helper to color-code the status
   const getStatusColor = (status) => {
      switch (status) {
         case 'Pending': return { bg: '#fef08a', text: '#854d0e' };
         case 'Accepted': return { bg: '#bfdbfe', text: '#1e40af' };
         case 'Picked Up': return { bg: '#ddd6fe', text: '#5b21b6' }; // Purple for dispatched!
         case 'Delivered': return { bg: '#dcfce7', text: '#166534' };
         default: return { bg: '#f3f4f6', text: '#374151' };
      }
   };

   return (
      <div style={{ maxWidth: '800px', margin: '40px auto', padding: '0 20px', fontFamily: 'Inter, sans-serif' }}>
         <h1 style={{ marginBottom: '24px' }}>My Orders & Tracking</h1>

         <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {orders.length === 0 ? (
               <p style={{ color: '#6b7280' }}>You haven't placed any orders yet.</p>
            ) : (
               orders.map(order => {
                  const statusColors = getStatusColor(order.status);

                  return (
                     <div key={order._id} style={{ border: '1px solid #e5e7eb', borderRadius: '8px', padding: '20px', backgroundColor: 'white', display: 'flex', flexDirection: 'column', gap: '12px' }}>

                        {/* Header: ID, Date, and Delivery Type */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #e5e7eb', paddingBottom: '12px' }}>
                           <div>
                              <span style={{ fontWeight: 'bold' }}>Order #{order._id.slice(-6).toUpperCase()}</span>
                              <span style={{ marginLeft: '12px', fontSize: '12px', color: '#6b7280' }}>
                                 {new Date(order.createdAt).toLocaleDateString()}
                              </span>
                           </div>
                           <span style={{
                              padding: '4px 10px',
                              borderRadius: '12px',
                              fontSize: '12px',
                              fontWeight: 'bold',
                              backgroundColor: order.deliveryType === 'Today' ? '#fef3c7' : '#d1fae5',
                              color: order.deliveryType === 'Today' ? '#d97706' : '#059669'
                           }}>
                              {order.deliveryType === 'Today' ? '⚡ Deliver Today' : '🗓️ Scheduled (15 Days)'}
                           </span>
                        </div>

                        {/* Items and Total */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                           <div style={{ fontSize: '14px', color: '#374151' }}>
                              {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                           </div>
                           <div style={{ fontWeight: 'bold', fontSize: '16px' }}>₹{order.totalAmount}</div>
                        </div>

                        {/* Tracking Status & Driver Info */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px', padding: '12px', backgroundColor: '#f9fafb', borderRadius: '6px' }}>

                           <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                              <span style={{ fontSize: '13px', color: '#6b7280' }}>Status:</span>
                              <span style={{
                                 padding: '4px 10px',
                                 borderRadius: '12px',
                                 fontSize: '13px',
                                 fontWeight: 'bold',
                                 backgroundColor: statusColors.bg,
                                 color: statusColors.text
                              }}>
                                 {order.status}
                              </span>
                           </div>

                           {/* Show driver info ONLY if a driver has accepted it */}
                           {order.driverId ? (
                              <div style={{ fontSize: '13px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                                 <span style={{ color: '#6b7280' }}>Driver Assigned:</span>
                                 <span style={{ fontWeight: 'bold' }}>🚗 {order.driverId.name} (📱 {order.driverId.phone || 'No phone'})</span>
                              </div>
                           ) : (
                              <div style={{ fontSize: '13px', color: '#9ca3af' }}>
                                 Waiting for driver...
                              </div>
                           )}

                        </div>
                     </div>
                  );
               })
            )}
         </div>
      </div>
   );
}