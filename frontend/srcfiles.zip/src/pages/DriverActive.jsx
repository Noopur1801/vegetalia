import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

export default function DriverActive() {
   const [orders, setOrders] = useState([]);
   const { token } = useContext(AuthContext);

   useEffect(() => {
      fetchActiveJobs();
   }, [token]);

   const fetchActiveJobs = async () => {
      try {
         const res = await axios.get('http://localhost:5000/api/orders/driver/active', {
            headers: { Authorization: `Bearer ${token}` }
         });
         setOrders(res.data);
      } catch (err) { console.error(err); }
   };

   const updateStatus = async (orderId, newStatus) => {
      try {
         await axios.put(`http://localhost:5000/api/orders/${orderId}/status`, { status: newStatus }, {
            headers: { Authorization: `Bearer ${token}` }
         });
         fetchActiveJobs(); // Refresh the board
      } catch (err) { alert("Failed to update status"); }
   };

   return (
      <div style={{ maxWidth: '800px', margin: '40px auto', padding: '0 20px', fontFamily: 'Inter, sans-serif' }}>
         <h1 style={{ marginBottom: '24px' }}>My Active Route</h1>

         <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {orders.length === 0 ? (
               <p style={{ color: '#6b7280' }}>No active deliveries. Go find some jobs!</p>
            ) : (
               orders.map(order => (
                  <div key={order._id} style={{ border: '1px solid #e5e7eb', borderRadius: '8px', overflow: 'hidden', backgroundColor: 'white' }}>

                     {/* Status Header */}
                     <div style={{ backgroundColor: order.status === 'Accepted' ? '#bfdbfe' : '#ddd6fe', padding: '12px 20px', fontWeight: 'bold', color: order.status === 'Accepted' ? '#1e40af' : '#5b21b6' }}>
                        Current Status: {order.status === 'Accepted' ? 'Heading to Vendor' : 'Out for Delivery'}
                     </div>

                     <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>

                        {/* Locations Grid */}
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', backgroundColor: '#f9fafb', padding: '16px', borderRadius: '8px' }}>

                           {/* Pick Up */}
                           <div>
                              <h4 style={{ margin: '0 0 8px 0', color: '#dc2626' }}>📍 PICK UP FROM:</h4>
                              {/* Assuming all items in an order are from the same vendor for this quick commerce logic */}
                              <p style={{ margin: 0, fontWeight: 'bold' }}>{order.items[0]?.vendorId?.businessName || 'Vendor'}</p>
                              <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#6b7280' }}>{order.items[0]?.vendorId?.address || 'Address hidden'}</p>
                           </div>

                           {/* Drop Off */}
                           <div>
                              <h4 style={{ margin: '0 0 8px 0', color: '#16a34a' }}>🏁 DROP OFF AT:</h4>
                              <p style={{ margin: 0, fontWeight: 'bold' }}>{order.buyerId?.name || 'Buyer'}</p>
                              <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#6b7280' }}>{order.buyerId?.address || 'Address hidden'}</p>
                           </div>
                        </div>

                        {/* Items & Actions */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px' }}>
                           <div style={{ fontSize: '14px' }}>
                              <strong>Package:</strong> {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                           </div>

                           <div>
                              {order.status === 'Accepted' && (
                                 <button onClick={() => updateStatus(order._id, 'Picked Up')} style={{ padding: '10px 20px', backgroundColor: '#8b5cf6', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                                    Mark as Picked Up
                                 </button>
                              )}
                              {order.status === 'Picked Up' && (
                                 <button onClick={() => updateStatus(order._id, 'Delivered')} style={{ padding: '10px 20px', backgroundColor: '#10b981', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                                    Mark as Delivered
                                 </button>
                              )}
                           </div>
                        </div>

                     </div>
                  </div>
               ))
            )}
         </div>
      </div>
   );
}