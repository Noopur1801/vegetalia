import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function AdminDashboard() {
   const [profile, setProfile] = useState(null);
   const [vendors, setVendors] = useState([]);
   const [loading, setLoading] = useState(true);

   // New edit state
   const [isEditing, setIsEditing] = useState(false);
   const [formData, setFormData] = useState({ fullName: '', department: '' });

   const { token, logout } = useContext(AuthContext);
   const navigate = useNavigate();

   useEffect(() => {
      const fetchData = async () => {
         try {
            const profileRes = await axios.get('http://localhost:5000/api/admin/profile', { headers: { Authorization: `Bearer ${token}` } });
            setProfile(profileRes.data);
            setFormData({
               fullName: profileRes.data.fullName || '',
               department: profileRes.data.department || ''
            });

            const vendorsRes = await axios.get('http://localhost:5000/api/admin/vendors', { headers: { Authorization: `Bearer ${token}` } });
            setVendors(vendorsRes.data);

         } catch (err) { console.error(err); } finally { setLoading(false); }
      };
      if (token) fetchData();
   }, [token]);

   const handleUpdate = async (e) => {
      e.preventDefault();
      try {
         const res = await axios.put('http://localhost:5000/api/admin/profile', formData, { headers: { Authorization: `Bearer ${token}` } });
         setProfile(res.data.profile);
         setIsEditing(false);
      } catch (err) { alert("Failed to update profile"); }
   };

   const verifyVendor = async (vendorId) => {
      try {
         await axios.put(`http://localhost:5000/api/admin/vendors/${vendorId}/verify`, {}, { headers: { Authorization: `Bearer ${token}` } });
         setVendors(vendors.map(v => v._id === vendorId ? { ...v, isVerified: true } : v));
      } catch (error) { alert("Failed to verify vendor"); }
   };

   const handleLogout = () => { logout(); navigate('/login'); };

   if (loading) return <div style={{ padding: '40px', textAlign: 'center' }}>Loading dashboard...</div>;

   return (
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 20px', fontFamily: 'Inter, sans-serif' }}>
         <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
            <h1 style={{ margin: 0, color: '#111827' }}>System Admin</h1>
            <button onClick={handleLogout} style={{ padding: '8px 16px', backgroundColor: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '500' }}>Sign Out</button>
         </div>

         {/* Admin Profile Box with Edit Mode */}
         <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '12px', border: '1px solid #e5e7eb', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)', marginBottom: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e5e7eb', paddingBottom: '12px', marginBottom: '16px' }}>
               <h2 style={{ fontSize: '18px', margin: 0 }}>Admin Details</h2>
               {!isEditing && <button onClick={() => setIsEditing(true)} style={{ padding: '6px 12px', backgroundColor: '#f3f4f6', color: '#374151', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>Edit Profile</button>}
            </div>

            {isEditing ? (
               <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div><label style={{ display: 'block', fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Full Name</label><input type="text" value={formData.fullName} onChange={(e) => setFormData({ ...formData, fullName: e.target.value })} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #d1d5db' }} required /></div>
                  <div><label style={{ display: 'block', fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Department</label><input type="text" value={formData.department} onChange={(e) => setFormData({ ...formData, department: e.target.value })} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #d1d5db' }} required /></div>
                  <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
                     <button type="submit" style={{ padding: '8px 16px', backgroundColor: '#7952b3', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>Save</button>
                     <button type="button" onClick={() => setIsEditing(false)} style={{ padding: '8px 16px', backgroundColor: 'transparent', color: '#6b7280', border: 'none', cursor: 'pointer' }}>Cancel</button>
                  </div>
               </form>
            ) : (
               <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div><p style={{ fontSize: '13px', color: '#6b7280', margin: '0 0 4px 0' }}>Full Name</p><p style={{ margin: 0, fontWeight: '500' }}>{profile?.fullName || 'Not configured yet'}</p></div>
                  <div><p style={{ fontSize: '13px', color: '#6b7280', margin: '0 0 4px 0' }}>Department</p><p style={{ margin: 0, fontWeight: '500' }}>{profile?.department || 'Not configured yet'}</p></div>
               </div>
            )}
         </div>

         {/* Vendor Approval Section (Unchanged) */}
         <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '12px', border: '1px solid #e5e7eb', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)' }}>
            <h2 style={{ fontSize: '18px', marginTop: 0, borderBottom: '1px solid #e5e7eb', paddingBottom: '12px' }}>Vendor Management</h2>
            {vendors.length === 0 ? (
               <p style={{ color: '#6b7280', fontSize: '14px' }}>No vendors registered yet.</p>
            ) : (
               <div style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {vendors.map(vendor => (
                     <div key={vendor._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
                        <div>
                           <h3 style={{ margin: '0 0 4px 0', fontSize: '15px' }}>{vendor.businessName || "Unnamed Business"}</h3>
                           <p style={{ margin: 0, fontSize: '13px', color: '#6b7280' }}>GST: {vendor.gstNumber || "N/A"} | Phone: {vendor.phone || "N/A"}</p>
                        </div>
                        {vendor.isVerified ? (
                           <span style={{ padding: '6px 12px', backgroundColor: '#dcfce7', color: '#166534', borderRadius: '20px', fontSize: '13px', fontWeight: '500' }}>Verified</span>
                        ) : (
                           <button onClick={() => verifyVendor(vendor._id)} style={{ padding: '6px 12px', backgroundColor: '#7952b3', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '13px' }}>
                              Approve Vendor
                           </button>
                        )}
                     </div>
                  ))}
               </div>
            )}
         </div>
      </div>
   );
}