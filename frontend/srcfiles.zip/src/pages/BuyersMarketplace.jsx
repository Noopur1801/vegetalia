import { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

export default function BuyerMarketplace() {
   const [products, setProducts] = useState([]);
   const [cart, setCart] = useState([]);
   const { token } = useContext(AuthContext);

   useEffect(() => {
      const fetchProducts = async () => {
         try {
            const res = await axios.get('http://localhost:5000/api/products/all', {
               headers: { Authorization: `Bearer ${token}` }
            });
            setProducts(res.data);
         } catch (err) { console.error(err); }
      };
      if (token) fetchProducts();
   }, [token]);

   const addToCart = (product) => {
      const existing = cart.find(item => item._id === product._id);
      if (existing) {
         setCart(cart.map(item => item._id === product._id ? { ...item, quantity: item.quantity + 1 } : item));
      } else {
         setCart([...cart, { ...product, quantity: 1 }]);
      }
   };

   const updateQuantity = (productId, amount) => {
      setCart(cart.map(item => {
         if (item._id === productId) {
            const newQuantity = item.quantity + amount;
            return { ...item, quantity: newQuantity };
         }
         return item;
      }).filter(item => item.quantity > 0)); // Removes the item if quantity drops to 0
   };

   const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);

   // UPDATED: Now accepts deliveryType ('Today' or 'Scheduled')
   const placeOrder = async (deliveryType) => {
      if (cart.length === 0) return alert("Your cart is empty!");

      try {
         await axios.post('http://localhost:5000/api/orders', {
            items: cart.map(c => ({
               productId: c._id,
               vendorId: c.vendorId,
               name: c.name,
               quantity: c.quantity,
               price: c.price
            })),
            totalAmount: cartTotal,
            deliveryType: deliveryType // <-- Sending 'Today' or 'Scheduled' to the backend
         }, {
            headers: { Authorization: `Bearer ${token}` }
         });

         alert(`Success! Order placed for ${deliveryType} delivery.`);
         setCart([]);
      } catch (err) {
         console.error(err);
         alert("Failed to place order.");
      }
   };

   return (
      <div style={{ maxWidth: '1000px', margin: '40px auto', padding: '0 20px', fontFamily: 'Inter, sans-serif', display: 'flex', gap: '24px' }}>

         {/* Products Grid */}
         <div style={{ flex: 2 }}>
            <h1 style={{ marginBottom: '24px' }}>Fresh Produce Market</h1>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '16px' }}>
               {products.map(p => (
                  <div key={p._id} style={{ border: '1px solid #e5e7eb', padding: '16px', borderRadius: '8px', backgroundColor: 'white' }}>

                     {/* NEW: Product Image for Quality Check */}
                     <img
                        src={p.imageUrl}
                        alt={p.name}
                        style={{ width: '100%', height: '150px', objectFit: 'cover', borderRadius: '4px', marginBottom: '12px' }}
                     />

                     <h3 style={{ margin: '0 0 4px 0' }}>{p.name}</h3>
                     <p style={{ margin: '0 0 12px 0', fontSize: '12px', color: '#6b7280' }}>By: {p.businessName}</p>
                     <span style={{ fontSize: '12px', backgroundColor: '#f3f4f6', padding: '2px 8px', borderRadius: '12px' }}>{p.category}</span>
                     <p style={{ margin: '12px 0 4px 0', fontWeight: 'bold' }}>₹{p.price} / {p.unit}</p>
                     <button onClick={() => addToCart(p)} style={{ width: '100%', padding: '8px', backgroundColor: '#2563eb', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', marginTop: '12px' }}>
                        Add to Cart
                     </button>
                  </div>
               ))}
               {products.length === 0 && <p>No products available right now.</p>}
            </div>
         </div>

         {/* Shopping Cart Sidebar */}
         <div style={{ flex: 1, backgroundColor: 'white', padding: '24px', borderRadius: '8px', border: '1px solid #e5e7eb', height: 'fit-content', position: 'sticky', top: '24px' }}>
            <h2 style={{ marginTop: 0, borderBottom: '1px solid #e5e7eb', paddingBottom: '12px' }}>Your Cart</h2>

            {cart.length === 0 ? (
               <p style={{ color: '#6b7280', fontSize: '14px' }}>Cart is empty</p>
            ) : (
               <div>
                  {cart.map(item => (
                     <div key={item._id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px', fontSize: '14px' }}>
                        {/* Interactive Quantity Controls */}
                        <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                           <button onClick={() => updateQuantity(item._id, -1)} style={{ padding: '2px 8px', cursor: 'pointer', border: '1px solid #d1d5db', background: 'white', borderRadius: '4px' }}>-</button>
                           <b>{item.quantity}</b>
                           <button onClick={() => updateQuantity(item._id, 1)} style={{ padding: '2px 8px', cursor: 'pointer', border: '1px solid #d1d5db', background: 'white', borderRadius: '4px' }}>+</button>
                           x {item.name}
                        </span>
                        <span>₹{item.price * item.quantity}</span>
                     </div>
                  ))}
                  <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: '12px', marginTop: '12px', display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
                     <span>Total:</span>
                     <span>₹{cartTotal}</span>
                  </div>

                  {/* NEW: Two Checkout Options (Flipkart Minutes Style) */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '20px' }}>
                     <button onClick={() => placeOrder('Today')} style={{ width: '100%', padding: '12px', backgroundColor: '#f59e0b', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                        ⚡ Deliver Today (Quick)
                     </button>

                     <button onClick={() => placeOrder('Scheduled')} style={{ width: '100%', padding: '12px', backgroundColor: '#10b981', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                        🗓️ Schedule (15 Days)
                     </button>
                  </div>
               </div>
            )}
         </div>

      </div>
   );
}