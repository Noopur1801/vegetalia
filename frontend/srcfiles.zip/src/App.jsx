import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import ProtectedRoute from './pages/ProtectedRoute.jsx';
import Register from './pages/Register.jsx';
import VendorDashboard from './pages/vendorDashboard.jsx';
import BuyerDashboard from './pages/BuyerDashboard.jsx';
import DriverDashboard from './pages/DriverDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import Navbar from './components/Navbar.jsx';
import VendorProducts from './pages/vendorProduct.jsx';
import BuyerMarketplace from './pages/BuyersMarketplace.jsx';
import DriverDeliveries from './pages/DriversDelivery.jsx';
import AdminOrders from './pages/Adminsorder.jsx';
import BuyerOrders from './pages/BuyersOrder.jsx';
import VendorSales from './pages/VendorsSales.jsx';
import DriverActive from './pages/DriverActive.jsx';

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Admin Only */}
        <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/admin/orders" element={<AdminOrders />} />
        </Route>

        {/* Vendor Only */}
        <Route element={<ProtectedRoute allowedRoles={['vendor']} />}>
          <Route path="/vendor-dashboard" element={<VendorDashboard />} />
          <Route path="/vendor/products" element={<VendorProducts />} />
          <Route path="/vendor/sales" element={<VendorSales />} />
        </Route>

        {/* Buyer Only */}
        <Route element={<ProtectedRoute allowedRoles={['buyer']} />}>
          <Route path="/buyer-dashboard" element={<BuyerDashboard />} />
          <Route path="/buyer/marketplace" element={<BuyerMarketplace />} />
          <Route path="/buyer/orders" element={<BuyerOrders />} />
        </Route>

        {/* Driver Only */}
        <Route element={<ProtectedRoute allowedRoles={['driver']} />}>
          <Route path="/driver-dashboard" element={<DriverDashboard />} />
          <Route path="/driver/deliveries" element={<DriverDeliveries />} />
          <Route path="/driver/active" element={<DriverActive />} />
        </Route>
      </Routes>
    </>
  );
}

export default App;